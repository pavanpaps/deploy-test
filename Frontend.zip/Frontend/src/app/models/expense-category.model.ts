export interface ExpenseCategory {
    cid: number;
    name: string;
  }
  